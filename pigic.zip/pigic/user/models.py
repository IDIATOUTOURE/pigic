from django.db import models 
from django.contrib.auth.models import AbstractUser

# Create your models here.

class CustomUser(AbstractUser):
    telephone = models.CharField(max_length = 10, blank = True, null = True)
    adresse = models.CharField(max_length = 200, blank = True, null = True)
    confirmation = models.CharField(max_length = 10, blank = True, null = True)
    USER_TYPE_CHOICES= [
        ('proprietaire', 'PROPRIETAIRE'),
        ('locataire', 'LOCATAIRE'),
        ('agent_immo', 'AGENT_IMMO'),
        ('entrepreneur', 'ENTREPRENEUR'),
    ]
    role = models.CharField(max_length = 20, choices = USER_TYPE_CHOICES, default = 'proprietaire')
    acceptation_CGU = models.BooleanField(default= False)
    user_valide = models.BooleanField(default= False)
    administrateur =models.BooleanField(default= False)
    def __str__(self):
        return f"{self.username}({self.get_role_display()})"

class Profile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete = models.CASCADE,related_name ='profile')
    domaine_expertise = models.CharField(max_length = 200, blank =True, null =True) 
    nom_entreprise = models.CharField(max_length = 200, blank =True, null =True) 
    nom_agence=models.CharField(max_length = 200, blank =True, null =True) 
    def __str__(self):
        return f"Profile de {self.user.username}"